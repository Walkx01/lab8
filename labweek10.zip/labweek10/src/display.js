import React from "react";

function display(props) {
  return <div>{props.name}</div>;
}

export default display;
