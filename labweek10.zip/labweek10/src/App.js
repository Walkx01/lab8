import logo from "./logo.svg";
import "./App.css";
import MyForm from "./myForm";
function App() {
  return (
    <>
      <MyForm />
    </>
  );
}

export default App;
